# How to run
1. open terminal in current directory
2. install dependencies: `pip install -r requirements.txt`
3. double click on `main.py` or type `python main.py` in the terminal